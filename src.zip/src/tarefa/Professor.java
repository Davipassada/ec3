package tarefa;

public class Professor extends Usuario {

	public Professor(String nome) {
		super(nome);
		this.nivelDePrivilegio = 3;
	}

	public boolean retiraItem(Item it) {

		if (it.isDisponivel()) {// checa se o livro esta disponivel
			it.empresta(this, getPrazoMaximo());// chama o metodo empresta da classe ite,m
			this.itensRetirados.add(it);
			return true;
		}
		return false;
	}

	public boolean devolveItem(Item it) {
		this.itensRetirados.remove(it);
		return true;
	}

	public boolean bloqueiaLivro(Livro livro, int prazo) {// bloqueia um livro
		return livro.bloqueia(this, prazo); // chama o método bloqueia da classe Livro
	}

	public boolean desbloqueiaLivro(Livro livro) {// desbloqueia o livro
		return livro.desbloqueia(this); // chama o método desbloqueia da classe Livro
	}

	public int getCotaMaxima() {// define quantidade maxima de livros que o usuario pode retirar
		return 5; // Professores retiram até 5 livros
	}

	public int getPrazoMaximo() {// define prazo maximo
		return 14; // Professores têm 14 dias para devolver
	}

	public String toString() {
		return "Prof. " + super.getNome();
	}

	public boolean isProfessor() {
		return true;
	}
}
