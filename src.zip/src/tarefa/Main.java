package tarefa;

public class Main {

	public static void main(String[] args) {
		Terminal s = new Terminal();
		s.menu();

	}
}
